package util;

public interface HasDebugInformation {

	public void showDebugInformation();

}
