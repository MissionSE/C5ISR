package gl;

public interface HasColor {
	public Color getColor();

	public void setColor(Color c);
}
