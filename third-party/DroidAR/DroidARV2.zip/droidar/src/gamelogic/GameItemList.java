package gamelogic;

public class GameItemList extends GameElementList<GameItem> {

}
