package geo;

public interface EdgeListener {

	void addEdgeToGraph(GeoGraph graph, GeoObj startPoint, GeoObj endPoint);

}