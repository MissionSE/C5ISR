package listeners;

import gui.MetaInfos;

public interface ItemSelectedListener {

	boolean onItemSelected(MetaInfos metaInfos);

}