package listeners.eventManagerListeners;

import util.Vec;

public interface CamRotationVecUpdateListener {
	public void onCamRotationVecUpdate(Vec target, Vec values, float timeDelta);
}
