package listeners;

import util.Wrapper;

@Deprecated
public interface ObjectCreateListener {

	boolean setWrapperToObject(Wrapper targetWrapper);

}
