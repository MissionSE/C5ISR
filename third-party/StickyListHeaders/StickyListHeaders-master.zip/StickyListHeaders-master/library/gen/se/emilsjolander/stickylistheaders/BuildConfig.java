/** Automatically generated file. DO NOT MODIFY */
package se.emilsjolander.stickylistheaders;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}