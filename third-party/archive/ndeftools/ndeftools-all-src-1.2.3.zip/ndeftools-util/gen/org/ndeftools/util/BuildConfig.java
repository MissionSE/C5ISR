/** Automatically generated file. DO NOT MODIFY */
package org.ndeftools.util;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}