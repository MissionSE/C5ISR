package rajawali.parser;

public interface IParser {

	public IParser parse() throws ParsingException;
}
